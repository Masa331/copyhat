module Main exposing (..)

import Html exposing (..)

main : Html msg
main =
  text "Hello Cold!"
/* Honvo */